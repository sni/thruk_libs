package TestAppNonMooseController;
use base qw/Catalyst/;
use Catalyst;

__PACKAGE__->setup;

1;

