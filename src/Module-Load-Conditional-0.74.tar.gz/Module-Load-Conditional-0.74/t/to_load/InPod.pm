use strict;
=pod

$VERSION = 1;

=cut

package InPod;

our $VERSION = 2;

1;
