package URI::connect;

use strict;
use warnings;

use base 'URI::http';

1;

